from flask import Blueprint, render_template, request, flash, redirect, url_for, session
from werkzeug.security import check_password_hash
from app.models import User,Patient,Doctor,db

admin_bp = Blueprint('admin_routes', __name__)

@admin_bp.route('/admin/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template("admin_login.html")

    if request.method == 'POST':
        data = request.form
        username = data.get("username")
        password = data.get("password")

        # Check if username and password are provided
        if not username or not password:
            flash('Username and password are required!', 'error')
            return redirect(url_for('admin_routes.login'))

        # Query user from the database
        user = User.query.filter_by(username=username).first()

        # Check if user exists
        if not user:
            flash('Invalid username', 'error')
            return redirect(url_for('admin_routes.login'))

        # Validate password
        if not check_password_hash(user.password, password):
            flash('Invalid password!', 'error')
            return redirect(url_for('admin_routes.login'))

        # Handle session creation
        session['user_id'] = user.id
        session['username'] = user.username
        session['is_admin'] = True  # Assuming this route is specific to admin logins

        # Successful login
        # flash('Admin Login Successful', 'success')
        return redirect(url_for('admin_routes.dashboard'))

@admin_bp.route('/admin/logout', methods=['GET'])
def logout():
    session.clear()
    flash('You have been logged out.', 'success')
    return redirect(url_for('admin_routes.login'))

@admin_bp.route('/dashboard', methods=['GET','POST'])
def dashboard():
    if 'user_id' not in session or not session.get('is_admin'):
        flash('Unauthorized access. Please log in as admin.', 'error')
        return redirect(url_for('admin_routes.login'))

    # Fetch pending and approved patients
    if request.method == 'GET':
        patients = Patient.query.filter_by(status='pending').all()
        approved_patients = Patient.query.filter_by(status='approved').all()
        rejected_patients = Patient.query.filter_by(status='rejected').all()
        doctors = Doctor.query.filter_by(status='pending').all()
        approved_doctors = Doctor.query.filter_by(status='approved').all()
        rejected_doctors =  Doctor.query.filter_by(status='rejected').all()

        return render_template('admin_dashboard.html', patients=patients, approved_patients=approved_patients,
                            doctors=doctors, approved_doctors=approved_doctors, rejected_doctors=rejected_doctors,rejected_patients=rejected_patients)

@admin_bp.route('/approve_patient/<int:patient_id>', methods=['POST'])
def approve_patient(patient_id):
    patient = Patient.query.get(patient_id)
    patient_name = patient.first_name + ' '+ patient.last_name
    if patient:
        patient.status = 'approved'
        db.session.commit()
        flash(f"{patient_name} request successfully approved", "success")
    return redirect(url_for('admin_routes.dashboard'))

@admin_bp.route('/reject_patient/<int:patient_id>', methods=['POST'])
def reject_patient(patient_id):
    patient = Patient.query.get(patient_id)
    patient_name = patient.first_name + ' '+ patient.last_name
    if patient:
        db.session.delete(patient)
        db.session.commit()
        flash(f"{patient_name} request rejected", "danger")

    return redirect(url_for('admin_routes.dashboard'))

# Routes to approve or reject doctors
@admin_bp.route('/approve_doctor/<int:doctor_id>', methods=['POST'])
def approve_doctor(doctor_id):
    doctor = Doctor.query.get(doctor_id)
    doctor_name = doctor.first_name + ' '+ doctor.last_name
    if doctor:
        doctor.status = 'approved'
        db.session.commit()
        flash(f"{doctor_name} request successfully approved", "success")
    return redirect(url_for('admin_routes.dashboard'))

@admin_bp.route('/reject_doctor/<int:doctor_id>', methods=['POST'])
def reject_doctor(doctor_id):
    doctor = Doctor.query.get(doctor_id)
    doctor_name = doctor.first_name + ' '+ doctor.last_name
    if doctor:
        db.session.delete(doctor)
        db.session.commit()
        flash(f"{doctor_name} request rejected", "danger")
    return redirect(url_for('admin_routes.dashboard'))

