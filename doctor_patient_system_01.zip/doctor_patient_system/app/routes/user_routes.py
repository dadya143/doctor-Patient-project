from flask import Blueprint,request,render_template,flash,redirect,url_for,session,jsonify
from app.models import db, Patient, Doctor,Appointment
from datetime import datetime,timedelta
from flask_jwt_extended import unset_jwt_cookies,create_access_token, jwt_required, get_jwt_identity,set_access_cookies

user_bp = Blueprint('user_routes', __name__)

@user_bp.route('/register/patient', methods=['GET', 'POST'])
def register_patient():
    if request.method == 'GET':
        return render_template('patient_register.html')

    if request.method == 'POST':
        data = request.form
        if Patient.query.filter_by(username=data['username']).first():
            flash("Username already exists. Please choose a different one.", "danger")
            return redirect(url_for('user_routes.register_patient'))

        if Patient.query.filter_by(phone_no=data['phone_no']).first():
            flash("Phone number already exists. Please provide a different one.", "danger")
            return redirect(url_for('user_routes.register_patient'))

        new_patient = Patient(
            first_name=data['first_name'],
            last_name=data['last_name'],
            date_of_birth=datetime.strptime(data['date_of_birth'], '%Y-%m-%d'),
            phone_no=data['phone_no'],
            email_id = data['email_id'],
            address=data['address'],
            username=data['username'],
            password=data['password'],
        )
        db.session.add(new_patient)
        db.session.commit()
        return render_template('patient_register.html', message="Patient registered successfully. Await admin approval.")


# Doctor Registration
@user_bp.route('/register/doctor', methods=['GET', 'POST'])
def register_doctor():
    if request.method == 'GET':
        return render_template('doctor_register.html')

    if request.method == 'POST':
        data = request.form
        if Doctor.query.filter_by(doctor_id=data['doctor_id']).first():
            flash("Doctor ID already exists. Please choose a different one.", "danger")
            return redirect(url_for('user_routes.register_doctor'))

        if Doctor.query.filter_by(username=data['username']).first():
            flash("Username already exists. Please choose a different one.", "danger")
            return redirect(url_for('user_routes.register_doctor'))

        if Doctor.query.filter_by(phone_no=data['phone_no']).first():
            flash("Phone number already exists. Please provide a different one.", "danger")
            return redirect(url_for('user_routes.register_doctor'))


        new_doctor = Doctor(
            doctor_id = data['doctor_id'],
            first_name=data['first_name'],
            last_name=data['last_name'],
            date_of_birth=datetime.strptime(data['date_of_birth'], '%Y-%m-%d'),
            phone_no=data['phone_no'],
            email_id = data['email_id'],
            address=data['address'],
            username=data['username'],
            password=data['password'],
            speciality=data['speciality'],
        )
        db.session.add(new_doctor)
        db.session.commit()
        return render_template('doctor_register.html', message="Doctor registered successfully. Await admin approval."), 201



@user_bp.route("/doctor/login", methods=["GET", "POST"])
def doctor_login():
    if request.method == 'GET':
        return render_template("doctor_login.html")

    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        # Authenticate user from the database
        user = Doctor.query.filter_by(username=username).first()
        if not user:
            flash('Invalid username', 'error')
            return redirect(url_for('user_routes.doctor_login'))

        if user.password !=password:
            flash('Invalid password!', 'error')
            return redirect(url_for('user_routes.doctor_login'))

        if user.status in ['rejected','pending']:
            flash('Needs Admin Approval', 'error')
            return redirect(url_for('user_routes.doctor_login'))

        if user and user.password==password:
            # Create JWT token
            access_token = create_access_token(identity=username,expires_delta=timedelta(hours=1))
            session['username'] = username
            session['logged_in'] = True
            session['access_token'] = access_token

            response = redirect(url_for("user_routes.doctor_dashboard"))
            set_access_cookies(response, access_token)
            # flash("Login successful!", "success")
            return response

@user_bp.route("/patient/login", methods=["GET", "POST"])
def patient_login():
    if request.method == 'GET':
        return render_template("patient_login.html")

    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        # Authenticate user from the database
        user = Patient.query.filter_by(username=username).first()
        if not user:
            flash('Invalid username', 'error')
            return redirect(url_for('user_routes.patient_login'))

        if user.password !=password:
            flash('Invalid password!', 'error')
            return redirect(url_for('user_routes.patient_login'))

        if user.status in ['rejected','pending']:
            flash('Needs Admin Approval', 'error')
            return redirect(url_for('user_routes.patient_login'))

        if user and user.password==password:
            # Create JWT token
            access_token = create_access_token(
                identity=username,
                expires_delta=timedelta(hours=1)
            )
            session['username'] = username
            session['logged_in'] = True
            session['access_token'] = access_token

            response = redirect(url_for("user_routes.patient_dashboard"))
            set_access_cookies(response, access_token)
            return response

@user_bp.route("/patient/logout")
def patient_logout():
    response = redirect(url_for("user_routes.patient_login"))
    unset_jwt_cookies(response)  # Clear JWT cookies
    session.clear()  # Clear session variables
    flash('You have been logged out.', 'success')
    return response

@user_bp.route("/doctor/logout")
def doctor_logout():
    response = redirect(url_for("user_routes.doctor_login"))
    unset_jwt_cookies(response)  # Clear JWT cookies
    session.clear()  # Clear session variables
    flash('You have been logged out.', 'success')
    return response

@user_bp.route("/patient/dashboard", methods=["GET"])
@jwt_required()
def patient_dashboard():
    if 'username' not in session:
        return redirect(url_for('patient_login'))

    username = get_jwt_identity()
    patient = Patient.query.filter_by(username=username).first()
    patient_name = patient.first_name + " "+ patient.last_name
    appointments = Appointment.query.filter_by(patient_id=patient.id).all()
    doctors = Doctor.query.all()

    doctors_with_appointments = (
        db.session.query(Doctor)
        .join(Appointment)
        .filter(Appointment.status == 'confirmed')
        .all()
    )

    doctor_appointments = {
        doctor: Appointment.query.filter_by(
            doctor_id=doctor.doctor_id, status='confirmed'
        ).all()
        for doctor in doctors_with_appointments
    }
    return render_template(
        "patient_dashboard.html",
        username=patient_name,
        doctor_appointments=doctor_appointments,
        appointments=appointments,
        doctors=doctors
    )


@user_bp.route('/doctor/dashboard', methods=["GET"])
@jwt_required()
def doctor_dashboard():
    if 'username' not in session:
        return redirect(url_for('doctor_login'))

    username = get_jwt_identity()
    doctor= Doctor.query.filter_by(username=username).first()
    doctor_name = doctor.first_name + " " + doctor.last_name
    # Fetching appointments and pending appointment requests for the doctor
    fixed_appointments = Appointment.query.filter_by(doctor_id=doctor.doctor_id, status='confirmed').all()
    pending_appointments = Appointment.query.filter_by(doctor_id=doctor.doctor_id, status='pending').all()

    # Render the dashboard template with the appointments
    return render_template("doctor_dashboard.html",
                           username=doctor_name,  # Replace with actual doctor's name
                           fixed_appointments=fixed_appointments,
                           pending_appointments=pending_appointments)

@user_bp.route('/doctor/dashboard/approve/<int:appointment_id>', methods=['POST'])
def approve_appointment(appointment_id):
    # Approve the appointment by changing its status
    appointment = Appointment.query.get(appointment_id)
    patient_name = appointment.patient.first_name + ' '+ appointment.patient.last_name
    if appointment:
        appointment.status = 'confirmed'
        db.session.commit()
        flash(f"{patient_name} appointment accepted", "success")
    return redirect(url_for('user_routes.doctor_dashboard'))

@user_bp.route('/doctor/dashboard/reject/<int:appointment_id>', methods=['POST'])
def reject_appointment(appointment_id):
    # Reject the appointment by deleting it
    appointment = Appointment.query.get(appointment_id)
    patient_name = appointment.patient.first_name + ' '+ appointment.patient.last_name
    if appointment:
        db.session.delete(appointment)
        db.session.commit()
        flash(f"{patient_name} appointment rejected", "danger")
    return redirect(url_for('user_routes.doctor_dashboard'))


@user_bp.route("/patient/dashboard/schedule", methods=["POST"])
@jwt_required()
def schedule_appointment():
    if 'username' not in session:
        return redirect(url_for('patient_login'))

    username = get_jwt_identity()
    patient = Patient.query.filter_by(username=username).first()
    doctor_id = request.form['doctor']
    date = request.form['date']

    confirmed_patient_appointment = Appointment.query.filter_by(
        patient_id=patient.id,
        appointment_date=date,
        status='confirmed'
    ).first()

    if confirmed_patient_appointment:
        flash("You already have a confirmed appointment on this date. Please choose another date.", "error")
        return redirect(url_for("user_routes.patient_dashboard"))

    # Check if the doctor already has an appointment on the requested date
    existing_appointment = Appointment.query.filter_by(doctor_id=doctor_id, appointment_date=date,status='confirmed').first()

    if existing_appointment:
        flash("Doctor has another appointment on this date. Please choose another date.", "error")
        return redirect(url_for("user_routes.patient_dashboard"))

    existing_patient_appointment = Appointment.query.filter_by(patient_id=patient.id, doctor_id=doctor_id, appointment_date=date,status='confirmed').first()
    pending_patient_appointment = Appointment.query.filter_by(patient_id=patient.id, doctor_id=doctor_id, appointment_date=date,status='pending').first()

    if pending_patient_appointment:
        flash("Your appointment is pending for approval", "error")
        return redirect(url_for("user_routes.patient_dashboard"))

    if existing_patient_appointment:
        flash("You have already booked an appointment with this doctor on the selected date.", "error")
        return redirect(url_for("user_routes.patient_dashboard"))

    # Create the appointment if doctor is available
    appointment = Appointment(patient_id=patient.id, doctor_id=doctor_id, appointment_date=date)
    db.session.add(appointment)
    db.session.commit()

    flash("Appointment requested successfully", "success")
    return redirect(url_for("user_routes.patient_dashboard"))