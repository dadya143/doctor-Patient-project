from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash

db = SQLAlchemy()

class Patient(db.Model):
    __tablename__ = 'patients'

    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    date_of_birth = db.Column(db.Date, nullable=False)
    email_id  = db.Column(db.String(50), nullable=False)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    address = db.Column(db.Text, nullable=False)
    phone_no = db.Column(db.String(10), nullable=False, unique=True)
    status = db.Column(db.String(20), default="pending")   # 'pending', 'approved', 'rejected'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    appointments = db.relationship('Appointment', backref='patient', lazy=True)

class Doctor(db.Model):
    __tablename__ = 'doctors'

    id = db.Column(db.Integer, primary_key=True)
    doctor_id = db.Column(db.Integer,nullable=False,unique=True)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    date_of_birth = db.Column(db.Date, nullable=False)
    phone_no = db.Column(db.String(10), nullable=False, unique=True)
    email_id  = db.Column(db.String(50), nullable=False)
    address = db.Column(db.Text, nullable=False)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    speciality = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(20), default="pending")  # 'pending', 'approved', 'rejected'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    appointments = db.relationship('Appointment', backref='doctor', lazy=True)

class User(db.Model):
    __tablename__ = 'admin'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(500), nullable=False)

    @classmethod
    def create_user(cls):
        # Check if the admin user already exists
        user = cls.query.filter_by(username='admin').first()
        if user:
            # Admin user already exists
            return

        # If no user exists, create the admin user
        hashed_password = generate_password_hash("admin")
        new_user = User(username="admin", password=hashed_password)
        db.session.add(new_user)
        db.session.commit()


class Appointment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.id'))
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.doctor_id'))
    appointment_date = db.Column(db.Date)
    status = db.Column(db.String(20), default='pending')   # e.g., pending, confirmed, canceled

    # patient = db.relationship("Patient", foreign_keys=[patient_id])
    # doctor = db.relationship("Doctor", foreign_keys=[doctor_id])