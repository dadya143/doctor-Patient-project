from flask import Flask, render_template,flash,redirect,url_for
from flask_jwt_extended import JWTManager
from app.routes.user_routes import user_bp
from app.models import db,User
from app.routes.admin_routes import admin_bp
from datetime import timedelta

def create_table(app):
    with app.app_context():
        db.create_all()
        User.create_user()


app = Flask(__name__)

# Configurations
app.config['SQLALCHEMY_DATABASE_URI'] = "postgresql://postgres:postgres@localhost:5432/clinic_db"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'CKcqS13BF5GQeKKQrDJizMiQsGrZpLrsE-sRlBPTcBA='  # Change this to a secure secret key
app.secret_key = 'your_secret_key'
app.config['JWT_TOKEN_LOCATION'] = ['headers', 'cookies']  # Accept tokens from headers and cookies
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=1)
app.config['JWT_REFRESH_TOKEN_EXPIRES'] = timedelta(days=30)
app.config['JWT_COOKIE_CSRF_PROTECT'] = False  # For development only
app.config['JWT_COOKIE_SECURE'] = False  # For development only

# Initialize extensions
jwt = JWTManager(app)
db.init_app(app)
create_table(app)

# Register routes
app.register_blueprint(user_bp)
app.register_blueprint(admin_bp)

@app.route('/',methods=['GET'])
def welcome():
    return render_template("base.html")

@app.route('/about_us',methods=['GET'])
def about_us():
    return render_template("about_us.html")

@jwt.expired_token_loader
def expired_token_callback(jwt_header, jwt_payload):
    flash("Session expired. Please log in again.", "error")
    return redirect(url_for('user_routes.patient_login'))

if __name__ == "__main__":
    app.run(debug=True)
