from celery import Celery
from flask_mail import Message
import time
from app.db.config import Config

config = Config()
celery = Celery(__name__, broker=config.CELERY_BROKER_URL,backend=config.CELERY_RESULT_BACKEND)

@celery.task(bind=True, retry_backoff=True, retry_backoff_max=600, max_retries=3, default_retry_delay=60)
def send_appointment_mail(self,patient_email,doctor_email,subject,body):

    """
    Celery task to send appointment-related emails.

    Args:
        self: The task instance.
        patient_email (str): The email address of the patient.
        doctor_email (str): The sender's (doctor's) email address.
        subject (str): Subject of the email.
        body (str): Body of the email.

    Raises:
        Retry the task in case of any exception.
    """
    try:
        time.sleep(5)

        from run import create_app
        app,mail = create_app()

        with app.app_context():
            msg = Message(
                subject=subject,
                sender=doctor_email,
                recipients=[patient_email],
                body=body
            )
            time.sleep(20)
            mail.send(msg)

    except Exception as e:
        # Retry the task on failure
        raise self.retry(exc=e)
