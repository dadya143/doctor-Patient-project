from flask import Flask, render_template, flash, redirect, url_for
from flask_jwt_extended import JWTManager
from app.routes.user_routes import user_bp
from app.db.models import db, User
from app.db.config import JWTConfig, Config, MailConfig
from app.routes.admin_routes import admin_bp
from flask_mail import Mail
from tasks.appointment_task import celery

# Function to create tables
def create_table(app):
    with app.app_context():
        db.create_all()  # Create tables
        User.create_user()  # Initialize any necessary users

# The create_app function that initializes the Flask app
def create_app():
    app = Flask(__name__)

    # Load configuration settings
    app.config.from_object(Config)
    app.config.from_object(JWTConfig)
    app.config.from_object(MailConfig)

    # Initialize JWT manager
    jwt = JWTManager(app)

    # Initialize the database
    db.init_app(app)
    create_table(app)

    # Initialize Flask-Mail
    mail = Mail(app)
    # mail.init_app(app)

    # Initialize Celery
    # celery = make_celery(app)
    celery.conf.update(app.config)

    # Register blueprints (routes)
    app.register_blueprint(user_bp)
    app.register_blueprint(admin_bp)

    # Define views
    @app.route('/', methods=['GET'])
    def welcome():
        return render_template("base.html")

    @app.route('/about_us', methods=['GET'])
    def about_us():
        return render_template("about_us.html")

    # Handle expired JWT tokens
    @jwt.expired_token_loader
    def expired_token_callback(jwt_header, jwt_payload):
        flash("Session expired. Please log in again.", "error")
        return redirect(url_for('user_routes.patient_login'))

    return app,mail

# Running the app
if __name__ == "__main__":
    app, _ = create_app()  # Create the app using the function
    app.run(debug=True)
