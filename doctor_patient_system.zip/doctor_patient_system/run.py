from flask import Flask, jsonify, request, jsonify, render_template
# from flask_jwt_extended import JWTManager
from app.routes.user_routes import user_bp
from app.models import db,User
from app.routes.admin_routes import admin_bp

def create_table(app):
    with app.app_context():
        db.create_all()
        User.create_user()


app = Flask(__name__)

# Configurations
app.config['SQLALCHEMY_DATABASE_URI'] = "postgresql://postgres:postgres@localhost:5432/clinic_db"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# app.config['JWT_SECRET_KEY'] = 'CKcqS13BF5GQeKKQrDJizMiQsGrZpLrsE-sRlBPTcBA='  # Change this to a secure secret key
app.secret_key = 'your_secret_key'

# Initialize extensions
db.init_app(app)
create_table(app)

# Register routes
app.register_blueprint(user_bp)
app.register_blueprint(admin_bp)

@app.route('/welcome',methods=['GET'])
def welcome():
    return render_template("base.html")

# @app.route('/')
# def hello():
#     return jsonify({'message': 'Welcome to the Admin Service!'})

if __name__ == "__main__":
    app.run(debug=True)
