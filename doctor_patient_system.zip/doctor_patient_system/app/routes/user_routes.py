from flask import Blueprint, request, jsonify,render_template,flash,redirect,url_for,Response
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity # type: ignore
from app.models import db, Patient, Doctor
from datetime import datetime
import requests

user_bp = Blueprint('user_routes', __name__)

@user_bp.route('/register/patient', methods=['GET', 'POST'])
def register_patient():
    if request.method == 'GET':
        return render_template('patient_register.html')

    if request.method == 'POST':
        data = request.form
        if Patient.query.filter_by(username=data['username']).first():
            flash("Username already exists. Please choose a different one.", "danger")
            return redirect(url_for('user_routes.register_patient'))

        new_patient = Patient(
            first_name=data['first_name'],
            last_name=data['last_name'],
            date_of_birth=datetime.strptime(data['date_of_birth'], '%Y-%m-%d'),
            phone_no=data['phone_no'],
            email_id = data['email_id'],
            address=data['address'],
            username=data['username'],
            password=data['password'],
        )
        db.session.add(new_patient)
        db.session.commit()
        return render_template('patient_register.html', message="Patient registered successfully. Await admin approval.")


# Doctor Registration
@user_bp.route('/register/doctor', methods=['GET', 'POST'])
def register_doctor():
    if request.method == 'GET':
        return render_template('doctor_register.html')

    if request.method == 'POST':
        data = request.form
        if Doctor.query.filter_by(username=data['username']).first():
            flash("Username already exists. Please choose a different one.", "danger")
            return redirect(url_for('user_routes.register_doctor'))

        new_doctor = Doctor(
            first_name=data['first_name'],
            last_name=data['last_name'],
            date_of_birth=datetime.strptime(data['date_of_birth'], '%Y-%m-%d'),
            phone_no=data['phone'],
            email_id = data['email_id'],
            address=data['address'],
            username=data['username'],
            password=data['password'],
            speciality=data['speciality'],
        )
        db.session.add(new_doctor)
        db.session.commit()
        return render_template('doctor_register.html', message="Doctor registered successfully. Await admin approval."), 201
