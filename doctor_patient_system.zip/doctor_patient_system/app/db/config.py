import os
from datetime import timedelta

class Config:
    """Base configuration with common settings."""
    SECRET_KEY = os.getenv('SECRET_KEY')  # Default secret key
    SQLALCHEMY_DATABASE_URI = 'postgresql://postgres:postgres@localhost:5432/clinic_db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = True
    CELERY_BROKER_URL = 'amqp://guest:guest@localhost:5672//'
    CELERY_RESULT_BACKEND = "rpc://"
    CELERY_RESULT_PERSISTENT = True
    CELERY_IGNORE_RESULT = False


class JWTConfig:
    """Configuration for JWT authentication."""
    JWT_SECRET_KEY = os.getenv('JWT_SECRET_KEY')  # Default key, can be changed
    JWT_TOKEN_LOCATION = ['headers', 'cookies']
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=1)
    JWT_REFRESH_TOKEN_EXPIRES = timedelta(days=30)
    JWT_COOKIE_CSRF_PROTECT = False  # For development only
    JWT_COOKIE_SECURE = False  # For development only


class MailConfig:
    MAIL_SERVER = 'sandbox.smtp.mailtrap.io'
    MAIL_PORT = 2525
    MAIL_USERNAME = os.getenv('MAIL_USERNAME')
    MAIL_PASSWORD = os.getenv('MAIL_PASSWORD')
    MAIL_USE_TLS = True
    MAIL_USE_SSL = False

